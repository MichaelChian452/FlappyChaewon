/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=22x22 chaewon chaewon.png 
 * Time-stamp: Monday 04/03/2023, 03:45:49
 * 
 * Image Information
 * -----------------
 * chaewon.png 22@22
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef CHAEWON_H
#define CHAEWON_H

extern const unsigned short chaewon[484];
#define CHAEWON_SIZE 968
#define CHAEWON_LENGTH 484
#define CHAEWON_WIDTH 22
#define CHAEWON_HEIGHT 22

#endif

