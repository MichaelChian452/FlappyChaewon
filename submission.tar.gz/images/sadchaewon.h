/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 sadchaewon sadchaewon.jpg 
 * Time-stamp: Sunday 04/02/2023, 23:59:30
 * 
 * Image Information
 * -----------------
 * sadchaewon.jpg 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef SADCHAEWON_H
#define SADCHAEWON_H

extern const unsigned short sadchaewon[38400];
#define SADCHAEWON_SIZE 76800
#define SADCHAEWON_LENGTH 38400
#define SADCHAEWON_WIDTH 240
#define SADCHAEWON_HEIGHT 160

#endif

