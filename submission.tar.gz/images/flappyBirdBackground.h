/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 flappyBirdBackground flappy-bird-background.jpg 
 * Time-stamp: Sunday 04/02/2023, 17:47:25
 * 
 * Image Information
 * -----------------
 * flappy-bird-background.jpg 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef FLAPPYBIRDBACKGROUND_H
#define FLAPPYBIRDBACKGROUND_H

extern const unsigned short flappybirdbackground[38400];
#define FLAPPYBIRDBACKGROUND_SIZE 76800
#define FLAPPYBIRDBACKGROUND_LENGTH 38400
#define FLAPPYBIRDBACKGROUND_WIDTH 240
#define FLAPPYBIRDBACKGROUND_HEIGHT 160

#endif

