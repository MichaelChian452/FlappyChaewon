/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 lesserafim lesserafim.jpg 
 * Time-stamp: Sunday 04/02/2023, 23:52:12
 * 
 * Image Information
 * -----------------
 * lesserafim.jpg 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef LESSERAFIM_H
#define LESSERAFIM_H

extern const unsigned short lesserafim[38400];
#define LESSERAFIM_SIZE 76800
#define LESSERAFIM_LENGTH 38400
#define LESSERAFIM_WIDTH 240
#define LESSERAFIM_HEIGHT 160

#endif

