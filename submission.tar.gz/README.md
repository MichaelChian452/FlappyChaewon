#FLAPPY CHAEWON

## Description
FLAPPY CHAEWON is a singleplayer game that draws inspiration from the timeless classic of Flappy Bird and K-pop star Chaewon from the group LE SSERAFIM. 

The game is written in C that runs on a GameBoy Advance Emulator with GameBoy Advance controls.

## Controls
GameBoy | Keyboard | | In-Game Usage
Start | Enter | Start the Game
Select | Backspace | Reset Entire Game
Up | Up Arrow | Move Up
Down | Down Arrow | Move Down
Left | Left Arrow | Move Left
Right | Right Arrow | Move Right